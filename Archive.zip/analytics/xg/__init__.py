"""Future xG analytics package."""
