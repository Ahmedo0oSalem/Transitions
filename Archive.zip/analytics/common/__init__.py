"""Shared analytics utilities."""
