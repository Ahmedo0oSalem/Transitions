"""Shared analytics metrics placeholder."""
