"""Analytics namespace for TRANSITIONS."""
